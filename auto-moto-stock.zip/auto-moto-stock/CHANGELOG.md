# Changelog

#### 1.0.0 - December 17, 2024

- Inital Version