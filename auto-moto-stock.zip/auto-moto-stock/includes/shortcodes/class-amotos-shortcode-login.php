<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
if (!class_exists('AMOTOS_Shortcode_Login')) {
    class AMOTOS_Shortcode_Login
    {
        /**
         * Output the cart shortcode.
         *
         * @param array $atts
         */
        public static function output($atts)
        {
            return amotos_get_template_html('account/login.php', array('atts' => $atts));
        }
    }
}