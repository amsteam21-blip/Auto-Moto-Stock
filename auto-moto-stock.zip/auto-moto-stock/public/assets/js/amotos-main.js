var AMOTOS = AMOTOS || {};
(function ($) {
    'use strict';
    var ajax_url = amotos_main_vars.ajax_url,
        confirm_yes_text = amotos_main_vars.confirm_yes_text,
        confirm_no_text = amotos_main_vars.confirm_no_text,
        loading_text = amotos_main_vars.loading_text,
        sending_text = amotos_main_vars.sending_text,
        decimals= amotos_main_vars.decimals,
        dec_point= amotos_main_vars.dec_point,
        thousands_sep= amotos_main_vars.thousands_sep;
    AMOTOS = {
        _ajax_process: false,
        init: function () {
            this.register_pattern_validator();
            this.show_wire_transfer_info();
            this.view_gallery();
            this.favorite();
            this.tooltip();
            // Vehicles Shortcode
            this.car_paging();
            this.move_link_to_carousel();

            // Vehicles Carousel
            this.execute_nav();
            // Vehicles Slider
            this.execute_slider_nav();
            //var $car_sync_wrap = $('.pagination-image.amotos-car-slider');
            //this.sync_car_carousel($car_sync_wrap);
            this.sc_sync_car_carousel();

            this.light_gallery();
            this.contact_manager_by_email();
            this.tab_collapse();
            this.start_rating();
            this.submit_rating();
            this.loan_calculator();
            this.login();
            this.register();
            this.showHidePassword();
        },
        show_wire_transfer_info: function(){
            $('input[type=radio][name=amotos_payment_method]').on('change', function() {
                if ($(this).val()=='wire_transfer')
                {
                    $('.amotos-wire-transfer-info').show();
                }
                else{
                    $('.amotos-wire-transfer-info').hide();
                }
            });
        },
        register_pattern_validator: function(){
            $.validator.addMethod("pattern", function (value, element, param) {
                if (this.optional(element)) {
                    return true;
                }
                if (typeof param === "string") {
                    param = new RegExp("^(?:" + param + ")$");
                }
                return param.test(value);
            }, "Invalid format.");
        },
        number_format: function(number,decimal) {
            decimal = (typeof decimal !== 'undefined') ?  decimal : decimals;

            // Strip all characters but numerical ones.
            number = (number + '').replace(/[^0-9+\-Ee.]/g, '');
            var n = !isFinite(+number) ? 0 : +number,
                prec = !isFinite(+decimal) ? 0 : Math.abs(decimal),
                sep = (typeof thousands_sep === 'undefined') ? ',' : thousands_sep,
                dec = (typeof dec_point === 'undefined') ? '.' : dec_point,
                s = '',
                toFixedFix = function (n, prec) {
                    var k = Math.pow(10, prec);
                    return '' + Math.round(n * k) / k;
                };
            // Fix for IE parseFloat(0.55).toFixed(0) = 0;
            s = (prec ? toFixedFix(n, prec) : '' + Math.round(n)).split('.');
            if (s[0].length > 3) {
                s[0] = s[0].replace(/\B(?=(?:\d{3})+(?!\d))/g, sep);
            }
            if ((s[1] || '').length < prec) {
                s[1] = s[1] || '';
                s[1] += new Array(prec - s[1].length + 1).join('0');
            }
            return s.join(dec);
        },
        tooltip: function () {
            //$('[data-toggle="tooltip"]').tooltip();
            $('[data-toggle="tooltip"]').each(function () {
                var configs = {
                    container: $(this).parent()
                };
                $(this).tooltip(configs);
            });
        },
        login_modal: function () {
            $("#amotos_signin_modal").modal('show');
        },
        get_page_number_from_href:function($href) {
            var $href_default = '',
                pattern = /paged=\d+/ig;
            if (new RegExp(pattern).test($href)) {
                $href_default = new RegExp(pattern).exec($href);
            }else{
                pattern = /page\/\d+/ig;
                $href_default = new RegExp(pattern).test($href) ? new RegExp(pattern).exec($href) : $href_default;
            }
            pattern = /\d+/g;
            return new RegExp(pattern).test($href_default) ? new RegExp(pattern).exec($href_default)[0] : 1;
        },
        view_gallery: function () {
            var _self = this;
            $(document).on('click','.car-view-gallery',function (event){
                event.preventDefault();
                if (_self._ajax_process) return;
                _self._ajax_process = true;
                var $this = $(this),
                    car_id = $this.attr('data-car-id'),
                    $icon = $this.find('i'),
                    gallery = $this.data('gallery'),
                    $wrap = $this.closest('.car-inner');
                if ($icon.length) {
                    $icon.data('class', $icon.attr('class'));
                }

                if (typeof gallery !== 'undefined') {
                    _self._ajax_process = false;
                    $this.lightGallery({
                        hash: false,
                        thumbnail:false,
                        dynamic: true,
                        dynamicEl: gallery,
                    });
                } else {
                    $.ajax({
                        type: 'post',
                        url: ajax_url,
                        dataType: 'json',
                        data: {
                            'action': 'amotos_view_gallery_ajax',
                            'car_id': car_id
                        },
                        beforeSend: function () {
                            $wrap.addClass('car-active-hover');
                            $icon.attr('class','fa fa-spinner fa-spin');
                        },
                        success: function (response) {
                            if (response.success) {
                                var _data = [];
                                for (var i = 0; i < response.data.length; i++) {
                                    _data.push({
                                        'src': response.data[i],
                                    });
                                }

                                if (typeof gallery === 'undefined') {
                                    $this.data('gallery', _data);
                                }

                                $this.lightGallery({
                                    hash: false,
                                    thumbnail:false,
                                    dynamic: true,
                                    dynamicEl: _data,
                                });
                            }
                            $wrap.removeClass('car-active-hover');
                            _self._ajax_process = false;
                            $icon.attr('class', $icon.data('class'));
                        },
                        error: function () {
                            _self._ajax_process = false;
                            $icon.attr('class', $icon.data('class'));
                            $wrap.removeClass('car-active-hover');
                        }
                    });
                }

            });
        },
        favorite: function () {
            $(document).on('click','.car-favorite', function (e) {
                e.preventDefault();
                if (!$(this).hasClass('on-handle')) {
                    var $this = $(this).addClass('on-handle'),
                        car_inner = $this.closest('.car-inner').addClass('car-active-hover'),
                        car_id = $this.attr('data-car-id'),
                        title_not_favorite = $this.attr('data-title-not-favorite'),
                        icon_not_favorite = $this.attr('data-icon-not-favorite'),
                        title_favorited = $this.attr('data-title-favorited'),
                        icon_favorited = $this.attr('data-icon-favorited');
                    $.ajax({
                        type: 'post',
                        url: ajax_url,
                        dataType: 'json',
                        data: {
                            'action': 'amotos_favorite_ajax',
                            'car_id': car_id
                        },
                        beforeSend: function () {
                            $this.children('i').addClass('fa-spinner fa-spin');
                        },
                        success: function (data) {
                            if ((typeof(data.added) == 'undefined') ||(data.added==-1)) {
                                AMOTOS.login_modal();
                            }
                            if (data.added==1) {
                                $this.children('i').removeClass(icon_not_favorite).addClass(icon_favorited);
                                $this.attr('title', title_favorited);
                            } else if (data.added==0) {
                                $this.children('i').removeClass(icon_favorited).addClass(icon_not_favorite);
                                $this.attr('title', title_not_favorite);
                            }
                            $this.children('i').removeClass('fa-spinner fa-spin');
                            $this.removeClass('on-handle');
                            car_inner.removeClass('car-active-hover');
                        },
                        error: function () {
                            $this.children('i').removeClass('fa-spinner fa-spin');
                            $this.removeClass('on-handle');
                            car_inner.removeClass('car-active-hover');
                        }
                    });
                }
            });
        },
        light_gallery: function () {
            $("[data-rel='amotos_light_gallery']").each(function () {
                var $this = $(this),
                    galleryId = $this.data('gallery-id');
                $this.on('click', function (event) {
                    event.preventDefault();
                    var _data = [];
                    var $index = 0;
                    var $current_src = $(this).attr('href');
                    var $current_thumb_src = $(this).data('thumb-src');

                    if (typeof galleryId != 'undefined') {
                        $('[data-gallery-id="' + galleryId + '"]').each(function (index) {
                            var src = $(this).attr('href'),
                                thumb = $(this).data('thumb-src'),
                                subHtml = $(this).attr('title');
                            if(src==$current_src && thumb==$current_thumb_src){
                                $index = index;
                            }
                            if(typeof(subHtml)=='undefined')
                                subHtml = '';
                            _data.push({
                                'src': src,
                                'downloadUrl': src,
                                'thumb': thumb,
                                'subHtml': subHtml
                            });
                        });

                        $this.lightGallery({
                            hash: false,
                            galleryId: galleryId,
                            dynamic: true,
                            dynamicEl: _data,
                            thumbWidth: 80,
                            index: $index,
                            loadYoutubeThumbnail: false
                        })
                    }
                });
            });
            $('a.amotos-view-video').on('click',function (event) {
                event.preventDefault();
                var $src = $(this).attr('data-src');
                $(this).lightGallery({
                    dynamic: true,
                    dynamicEl: [{
                        'src': $src,
                        'thumb': '',
                        'subHtml': ''
                    }]
                });
            });
        },
        show_loading: function ($text) {
            if($text=='undefined' || $text=='' || $text==null) {
                $text=loading_text;
            }
            var template = wp.template('amotos-processing-template');
            $('body').append(template({'ico': 'fa fa-spinner fa-spin', 'text': $text}));
        },

        change_loading_status: function ($ico_class, $text) {
            $('i', '.amotos-processing').removeClass('fa-spinner fa-spin').addClass($ico_class);
            $('span', '.amotos-processing').text($text);
        },

        close_loading: function ($timeout) {
            if (typeof $timeout == 'undefined' || $timeout == null) {
                $timeout = 500;
            }
            if ($timeout == 0) {
                $('.amotos-processing').remove();
            } else {
                setTimeout(function () {
                    $('.amotos-processing').fadeOut(function () {
                        $('.amotos-processing').remove();
                    });
                }, $timeout);
            }
        },
        popup_alert: function ($ico_class, $title, $message) {
            var template = wp.template('amotos-dialog-template');
            $('body').append(template({ico: $ico_class, message: $message}));
            $("#amotos-dialog-popup").dialog({
                title: $title,
                resizable: false,
                closeOnEscape: true,
                modal: true,
                buttons: {
                    Ok: function() {
                        $(this).dialog( 'close' );
                        $(this).dialog('destroy').remove();
                    }
                }
            });
        },
        confirm_dialog: function ($title, $message, yes_callback, no_callback) {
            var template = wp.template('amotos-dialog-template');
            $('body').append(template({ico: 'fa fa-question-circle', message: $message}));
            $("#amotos-dialog-popup").dialog({
                title: $title,
                resizable: false,
                closeOnEscape: true,
                modal: true,
                buttons: [
                    {
                        text: confirm_yes_text, click: function () {
                        if (yes_callback)
                            yes_callback();
                        $(this).dialog('destroy').remove();
                    }
                    },
                    {
                        text: confirm_no_text, click: function () {
                        if (no_callback)
                            no_callback();
                        $(this).dialog('close');
                        $(this).dialog('destroy').remove();
                    }
                    }
                ]
            });
        },
        set_item_effect: function ($items, $effect) {
            if ($effect == 'hide') {
                $items.css('transition', 'opacity 1.5s linear, transform 1s');
                $items.css('-webkit-transition', 'opacity 1.5s linear, transform 1s');
                $items.css('-moz-transition', 'opacity 1.5s linear, transform 1s');
                $items.css('-ms-transition', 'opacity 1.5s linear, transform 1s');
                $items.css('-o-transition', 'opacity 1.5s linear, transform 1s');
                $items.css('opacity', 0);
                $items.css('transform', 'scale(0.2)');
                $items.css('-ms-transform', 'scale(0.2)');
                $items.css('-webkit-transform', 'scale(0.2)');
            }
            if ($effect == 'show') {
                for (var $i = 0; $i < $items.length; $i++) {
                    (function ($index) {
                        var $delay = 10 * $i;
                        setTimeout(function () {
                            $($items[$index]).css('opacity', 1);
                            $($items[$index]).css('transform', 'scale(1)');
                            $($items[$index]).css('-ms-transform', 'scale(1)');
                            $($items[$index]).css('-webkit-transform', 'scale(1)');
                        }, $delay);
                    })($i);
                }
            }
        },
        select_term: function () {
            var $elm = $('select.car-filter-mb');
            $elm.off();
            $($elm).on('change', function (event) {
                var $this = $(this);
                $this.attr('disabled', 'disabled');
                event.preventDefault();
                var optionValue = $('option:selected', $this).attr('value'),
                    object = $this.parent().prev().children('[data-filter="' + optionValue + '"]');
                object.click();
            });
        },
        contact_manager_by_email: function() {
            var _self = this;
            $('.amotos__btn-submit-contact-form').on('click',function (event){
                event.preventDefault();
                var $this = $(this),
                    $form = $this.closest('form');
                if ($form[0].checkValidity() === false) {
                    $form.addClass('was-validated');
                    return;
                }
                var $message = $form.find('.amotos__message');

                if (_self._ajax_process) return;
                _self._ajax_process = true;
                $.ajax({
                    type: 'post',
                    url: ajax_url,
                    dataType: 'json',
                    data: $form.serialize(),
                    beforeSend: function () {
                        $message.html('<span class="success text-success"> ' + sending_text + '</span>');
                    },
                    success: function (response) {
                        if (response.success) {
                            $message.html('<span class="success text-success"><i class="fa fa-check"></i> ' + response.message + '</span>');
                        } else {
                            if (typeof amotos_reset_recaptcha == 'function') {
                                amotos_reset_recaptcha();
                            }
                            $message.html('<span class="error text-danger"><i class="fa fa-close"></i> ' + response.message + '</span>');
                        }
                    },
                    complete: function(){
                        _self._ajax_process = false;
                    },
                    error: function () {

                    }
                });
            });
        },

        car_paging: function() {
            var handle = true;
            $('.paging-navigation', '.car-paging-wrap').each(function () {
                $('a', $(this)).off('click').on('click', function (event) {
                    event.preventDefault();
                    if(handle) {
                        handle = false;
                        var $this = $(this);
                        var href = $this.attr('href'),
                            data_paged = AMOTOS.get_page_number_from_href(href),
                            data_contain = $this.closest('.car-paging-wrap'),
                            car_content = $this.closest('.amotos-car').find('.car-content');
                        $.ajax({
                            url: data_contain.data('admin-url'),
                            data: {
                                action: 'amotos_car_paging_ajax',
                                layout: data_contain.data('layout'),
                                items_amount: data_contain.data('items-amount'),
                                columns: data_contain.data('columns'),
                                image_size: data_contain.data('image-size'),
                                columns_gap: data_contain.data('columns-gap'),
                                view_all_link: data_contain.data('view-all-link'),
                                paged: data_paged,
                                car_type: data_contain.data('car-type'),
                                car_status: data_contain.data('car-status'),
                                car_styling: data_contain.data('car-styling'),
                                car_city: data_contain.data('car-city'),
                                car_state: data_contain.data('car-state'),
                                car_neighborhood: data_contain.data('car-neighborhood'),
                                car_label: data_contain.data('car-label'),
                                car_featured: data_contain.data('car-featured'),
                                author_id: data_contain.data('author-id'),
                                manager_id: data_contain.data('manager-id')
                            },
                            success: function (html) {
                                var $newElems = $('.car-item', html),
                                    paging = $('.car-paging-wrap', html);

                                car_content.css('opacity', 0);

                                car_content.html($newElems);
                                AMOTOS.set_item_effect($newElems, 'hide');
                                var contentTop = car_content.offset().top - 30;
                                $('html,body').animate({scrollTop: +contentTop + 'px'}, 500);
                                car_content.css('opacity', 1);
                                car_content.imagesLoaded(function () {
                                    $newElems = $('.car-item', car_content);
                                    AMOTOS.set_item_effect($newElems, 'show');
                                    car_content.closest('.amotos-car').find('.car-paging-wrap').html(paging.html());
                                    AMOTOS.car_paging();
                                    AMOTOS.car_paging_control();
                                    AMOTOS.favorite();
                                    AMOTOS.tooltip();
                                    AMOTOS_Compare.register_event_compare();
                                });
                                handle = true;
                            },
                            error: function () {
                                handle = true;
                            }
                        });
                    }
                })
            });
        },
        car_paging_control: function() {
            $('.paging-navigation', '.amotos-car').each(function () {
                var $this = $(this);
                if($this.find('a.next').length === 0) {
                    $this.addClass('next-disable');
                } else {
                    $this.removeClass('next-disable');
                }
            });
        },
        move_link_to_carousel: function() {
            $('.car-carousel').each(function () {
                var this_elm = $(this);
                $('.owl-carousel', this_elm).on('owlInitialized',function() {
                    if (this_elm.data('view-all-link') != undefined && (this_elm.children('.owl-loaded').hasClass('owl-nav-top-right') ||
                        this_elm.children('.owl-loaded').hasClass('owl-nav-bottom-center'))) {
                        var view_all_link = this_elm.find('.view-all-link');
                        if(view_all_link.length > 0 && !this_elm.find('.owl-nav').hasClass('disabled')) {
                            view_all_link.removeClass('mg-top-60 sm-mg-top-40');
                            this_elm.find('.owl-nav').addClass('has-view-all');
                            this_elm.find('.owl-nav').append(view_all_link[0].outerHTML);
                            view_all_link.remove();
                        }
                    }
                    if(this_elm.hasClass('owl-move-nav-par-with-heading') && this_elm.find('.amotos-heading').length > 0
                        && !this_elm.find('.amotos-heading').hasClass('heading-contain-owl-nav')) {
                        this_elm.find('.amotos-heading').addClass('heading-contain-owl-nav owl-nav-inline');

                        if (this_elm.find('.has-view-all').length > 0) {
                            this_elm.find('.amotos-heading').addClass('owl-nav-size-sm');
                        }


                        this_elm.find('.owl-nav').insertAfter(this_elm.find('.amotos-heading').children('h2'));
                    }
                });
            });
        },

        execute_nav: function() {
            $('.amotos-car-carousel').each(function () {
                var this_elm = $(this),
                    navigation_wrap = $('.navigation-wrap', this_elm),
                    carousel_item = $('.owl-carousel .car-item', this_elm);
                AMOTOS.amotos_calc_column_padding(navigation_wrap, carousel_item);
                $('.owl-carousel', this_elm).on('owlInitialized',function() {
                    var $this = $(this),
                        nav = $('.owl-nav', $this);
                    if (navigation_wrap.length > 0 && nav.length > 0) {
                        nav.detach().appendTo(navigation_wrap);
                    }
                    navigation_wrap.addClass('owl-nav-inline');
                    AMOTOS.amotos_calc_column_padding(navigation_wrap, $('.car-item', $this));
                });
            });
        },
        amotos_calc_column_padding: function(navigation_wrap, carousel_item) {
            return;
            if(navigation_wrap.height() < carousel_item.height()) {
                var padding = Math.floor((carousel_item.height() - navigation_wrap.height()) / 2);
                navigation_wrap.css({
                    'padding-top': padding + 'px',
                    'padding-bottom': padding + 'px'
                });
            }
        },

        execute_slider_nav: function() {
            return;
            $('.amotos-car-slider.navigation-middle').each(function () {
                AMOTOS.amotos_calc_nav_top($('.owl-carousel', $(this)));
                $('.owl-carousel', $(this)).on('owlInitialized',function() {
                    var this_elm = $(this),
                        nav = $('.owl-nav', this_elm);
                    nav.addClass('container');
                    setTimeout(function(){
                        AMOTOS.amotos_calc_nav_top(this_elm);
                    },20);
                });
            });
        },
        amotos_calc_nav_top: function(carousel_wrap) {
            var nav = $('.owl-nav', carousel_wrap),
                wrap_height = $('.car-item', carousel_wrap).outerHeight(),
                content_height = $('.block-center-inner', carousel_wrap).outerHeight(),
                top = Math.floor((wrap_height - content_height) / 2);
            nav.css('top', top + 'px');
        },
        sc_sync_car_carousel: function () {
            var _self = this;
            $('.pagination-image.amotos-car-slider').each(function (index,element){
                _self.sync_car_carousel($(element));
            });
        },
        sync_car_carousel: function($carSyncWrap) {
            var isRTL = $('body').hasClass('rtl'),
                $sliderMain = $carSyncWrap.find('.car-content-slider'),
                $sliderThumb = $carSyncWrap.find('.car-image-slider');
            $sliderMain.owlCarousel({
                items: 1,
                navElement: 'div',
                autoHeight: true,
                nav: false,
                dots: false,
                loop: false,
                smartSpeed: 500,
                rtl: isRTL
            }).on('changed.owl.carousel', syncPosition);
            $sliderThumb.on('initialized.owl.carousel', function () {
                $sliderThumb.find(".owl-item").eq(0).addClass("current");
            }).owlCarousel({
                nav: false,
                navElement: 'div',
                dots: false,
                rtl: isRTL,
                margin: 10,
                responsive: {
                    992: {
                        items: 4
                    },
                    768: {
                        items: 3
                    },
                    480: {
                        items: 2
                    },
                    0: {
                        items: 1
                    }
                }
            }).on('changed.owl.carousel', syncPosition2);

            function syncPosition(el) {
                //if you set loop to false, you have to restore this next line
                var current = el.item.index;

                $sliderThumb
                    .find(".owl-item")
                    .removeClass("current")
                    .eq(current)
                    .addClass("current");
                var onscreen = $sliderThumb.find('.owl-item.active').length - 1;
                var start = $sliderThumb.find('.owl-item.active').first().index();
                var end = $sliderThumb.find('.owl-item.active').last().index();

                if (current > end) {
                    $sliderThumb.data('owl.carousel').to(current, 500, true);
                }
                if (current < start) {
                    $sliderThumb.data('owl.carousel').to(current - onscreen, 500, true);
                }
            }

            function syncPosition2(el) {
                var number = el.item.index;
                $sliderMain.data('owl.carousel').to(number, 500, true);
            }

            $sliderThumb.on("click", ".owl-item", function (e) {
                e.preventDefault();
                if ($(this).hasClass('current')) return;
                var number = $(this).index();
                $sliderMain.data('owl.carousel').to(number, 500, true);
            });
        },
        tab_collapse: function () {
            $('[data-tabcollapse]').tabCollapse();
        },
        start_rating: function () {
            var isRTL = $('body').hasClass('rtl');
            $('.amotos__start-rating').each(function (){
                var $this = $(this);
                var defaults = {
                    step: 1,
                    showClear: false,
                    showCaption:false,
                    filledStar: '<i class="fa fa-star"></i>',
                    emptyStar: '<i class="fa fa-star-o"></i>',
                    clearButton: '<i class="fa fa-minus-circle"></i>',
                    rtl: isRTL,

                };
                var config = $.extend({}, defaults, $this.data("options"));
                $this.rating(config);
            });
        },
        submit_rating: function (){
            var _self = this;
            $('.amotos__btn-submit-rating').on('click', function (event) {
                event.preventDefault();
                var $this = $(this),
                    $form = $this.closest('form');
                if ($form[0].checkValidity() === false) {
                    $form.addClass('was-validated');
                    return;
                }

                if (_self._ajax_process) return;
                _self._ajax_process = true;
                $.ajax({
                    type: 'POST',
                    url: ajax_url,
                    data: $form.serialize(),
                    dataType: 'json',
                    beforeSend: function( ) {
                        $this.children('i').remove();
                        $this.append('<i class="fa fa-spinner fa-spin"></i>');
                    },
                    success: function(res) {
                        if (res.success) {
                            window.location.reload();
                        }
                    },
                    complete: function(){
                        _self._ajax_process = false;
                        $this.children('i').removeClass('fa fa-spinner fa-spin');
                        $this.children('i').addClass('fa fa-check');
                    }
                });
            });
        },
        loan_calculator: function (){
            var _self = this;
            $('.amotos__btn-submit-loan-calculator').on('click',function (event){
                event.preventDefault();
                var $this = $(this),
                    $form = $this.closest('form');
                if ($form[0].checkValidity() === false) {
                    $form.addClass('was-validated');
                    return;
                }

                var $sale_price = $form.find('[name="sale_price"]'),
                    $down_payment = $form.find('[name="down_payment"]'),
                    $term_years = $form.find('[name="term_years"]'),
                    $interest_rate = $form.find('[name="interest_rate"]'),
                    sale_price = $sale_price.val(),
                    down_payment = $down_payment.val(),
                    term_years = parseInt($term_years.val(),10),
                    interest_rate = parseFloat($interest_rate.val(),10) / 100,
                    interest_rate_month = interest_rate / 12,
                    interest_rate_bi_weekly = interest_rate / 26,
                    interest_rate_weekly = interest_rate / 52,
                    number_of_payments_month = term_years * 12,
                    number_of_payments_bi_weekly = term_years * 26,
                    number_of_payments_weekly = term_years * 52,
                    loan_amount = sale_price - down_payment,
                    monthly_payment = parseFloat((loan_amount * interest_rate_month) / (1 - Math.pow(1 + interest_rate_month, -number_of_payments_month))).toFixed(2),
                    bi_weekly_payment = parseFloat((loan_amount * interest_rate_bi_weekly) / (1 - Math.pow(1 + interest_rate_bi_weekly, -number_of_payments_bi_weekly))).toFixed(2),
                    weekly_payment = parseFloat((loan_amount * interest_rate_weekly) / (1 - Math.pow(1 + interest_rate_weekly, -number_of_payments_weekly))).toFixed(2);

                if (monthly_payment === 'NaN') {
                    monthly_payment = 0;
                }
                if (bi_weekly_payment === 'NaN') {
                    bi_weekly_payment = 0;
                }
                if (weekly_payment === 'NaN') {
                    weekly_payment = 0;
                }


                loan_amount =  AMOTOS.number_format(loan_amount);
                monthly_payment = AMOTOS.number_format(monthly_payment);
                bi_weekly_payment = AMOTOS.number_format(bi_weekly_payment);
                weekly_payment = AMOTOS.number_format(weekly_payment);
                if (amotos_main_vars.currency_position === 'before') {
                    loan_amount =  amotos_main_vars.currency + loan_amount;
                    monthly_payment =  amotos_main_vars.currency + monthly_payment;
                    bi_weekly_payment =  amotos_main_vars.currency + bi_weekly_payment;
                    weekly_payment =  amotos_main_vars.currency + weekly_payment;
                } else {
                    loan_amount = loan_amount +  amotos_main_vars.currency;
                    monthly_payment = monthly_payment +  amotos_main_vars.currency;
                    bi_weekly_payment = bi_weekly_payment +  amotos_main_vars.currency;
                    weekly_payment = weekly_payment +  amotos_main_vars.currency;
                }

                var template = wp.template('amotos__mc_template');
                var content = template({
                    loan_amount: loan_amount,
                    years: term_years,
                    monthly_payment: monthly_payment,
                    bi_weekly_payment: bi_weekly_payment,
                    weekly_payment: weekly_payment
                });

                if ($form.find('.amotos__mc-result').length) {
                    $form.find('.amotos__mc-result').remove();
                }
                $form.append(content);

            });
        },
        login: function () {
            var _self = this;
            $('.amotos-login-button').on('click',function (event){
                event.preventDefault();
                var $this = $(this),
                    $form = $this.closest('form');
                if ($form[0].checkValidity() === false) {
                    $form.addClass('was-validated');
                    return;
                }
                if (_self._ajax_process) return;
                _self._ajax_process = true;

                var $message = $form.find('.amotos_messages');
                var $redirect_url = $this.data('redirect-url');


                $.ajax({
                    type: 'post',
                    url: ajax_url,
                    dataType: 'json',
                    data: $form.serialize(),
                    beforeSend: function () {
                        $message.html('<span class="success text-success"> ' + loading_text + '</span>');
                    },
                    success: function (response) {
                        if (response.success) {
                            $message.html('<span class="success text-success"><i class="fa fa-check"></i> ' + response.message + '</span>');
                            if ($redirect_url === '') {
                                window.location.reload();
                            }
                            else {
                                window.location.href = $redirect_url;
                            }
                        } else {
                            if (typeof amotos_reset_recaptcha == 'function') {
                                amotos_reset_recaptcha();
                            }
                            $message.html('<span class="error text-danger"><i class="fa fa-close"></i> ' + response.message + '</span>');
                        }
                    },
                    complete: function(){
                        _self._ajax_process = false;
                    },
                    error: function () {

                    }
                });
            });

            $('.amotos_forgetpass').on('click',function (event){
                event.preventDefault();
                var $this = $(this),
                    $form = $this.closest('form');
                if ($form[0].checkValidity() === false) {
                    $form.addClass('was-validated');
                    return;
                }

                if (_self._ajax_process) return;
                _self._ajax_process = true;

                var $message = $form.find('.amotos_messages');

                $.ajax({
                    type: 'post',
                    url: ajax_url,
                    dataType: 'json',
                    data: $form.serialize(),
                    beforeSend: function () {
                        $message.html('<span class="success text-success"> ' + loading_text + '</span>');
                    },
                    success: function (response) {
                        if (response.success) {
                            $message.html('<span class="success text-success"><i class="fa fa-check"></i> ' + response.message + '</span>');
                        } else {
                            if (typeof amotos_reset_recaptcha == 'function') {
                                amotos_reset_recaptcha();
                            }
                            $message.html('<span class="error text-danger"><i class="fa fa-close"></i> ' + response.message + '</span>');
                        }
                    },
                    complete: function(){
                        _self._ajax_process = false;
                    },
                    error: function () {

                    }
                });
            });

            $('.amotos-reset-password').on('click',function (event){
                event.preventDefault();
                var $this = $(this),
                    $login_wrap = $this.closest('.amotos-login-wrap'),
                    $reset_password_wrap = $login_wrap.next('.amotos-reset-password-wrap');
                $login_wrap.slideUp('slow');
                $reset_password_wrap.slideDown('slow');
                $reset_password_wrap.find('.reset_password_user_login').focus();
            });

            $('.amotos-back-to-login').on('click',function (event){
                event.preventDefault();
                var $this = $(this),
                    $reset_password_wrap = $this.closest('.amotos-reset-password-wrap'),
                    $login_wrap = $reset_password_wrap.prev('.amotos-login-wrap');

                $reset_password_wrap.slideUp('slow')
                $login_wrap.slideDown('slow');
                $login_wrap.find('.login_user_login').focus();
            });

            $('#amotos_signin_modal').on('shown.bs.modal hide.bs.modal', function () {
                $('.amotos-back-to-login', $('#amotos_signin_modal')).click();
            });
        },
        register: function (){
            var _self = this;
            $('.amotos-register-button').on('click',function (event){
                event.preventDefault();
                var $this = $(this),
                    $form = $this.closest('form');
                if ($form[0].checkValidity() === false) {
                    $form.addClass('was-validated');
                    return;
                }
                if (_self._ajax_process) return;
                _self._ajax_process = true;

                var $message = $form.find('.amotos_messages');
                var $redirect_url = $this.data('redirect-url');


                $.ajax({
                    type: 'post',
                    url: ajax_url,
                    dataType: 'json',
                    data: $form.serialize(),
                    beforeSend: function () {
                        $message.html('<span class="success text-success"> ' + loading_text + '</span>');
                    },
                    success: function (response) {
                        if (response.success) {
                            $message.html('<span class="success text-success"><i class="fa fa-check"></i> ' + response.message + '</span>');
                            if ($redirect_url === '') {
                                setTimeout(function () {
                                    $("#amotos_login_modal_tab").click();
                                }, 4000);
                            }
                            else {
                                window.location.href = $redirect_url;
                            }
                        } else {
                            if (typeof amotos_reset_recaptcha == 'function') {
                                amotos_reset_recaptcha();
                            }
                            $message.html('<span class="error text-danger"><i class="fa fa-close"></i> ' + response.message + '</span>');
                        }
                    },
                    complete: function(){
                        _self._ajax_process = false;
                    },
                    error: function () {

                    }
                });
            });
        },
        showHidePassword: function () {
            $('.amotos__show-password').on('click', function (e) {
                e.preventDefault();
                var $this = $(this),
                    $wrap = $this.closest('.input-group'),
                    $input_pass = $wrap.find('.amotos__password');

                var $icon = $(this).find('i');
                if ($input_pass.attr('type') === 'password') {
                    $input_pass.attr('type', 'text');
                    $icon.removeClass('fa-eye');
                    $icon.addClass('fa-eye-slash');
                } else {
                    $input_pass.attr('type', 'password');
                    $icon.removeClass('fa-eye-slash');
                    $icon.addClass('fa-eye');
                }
            });
        }
    };
    $(document).ready(function () {
        AMOTOS.init();
    });
    $(window).resize(function () {
        setTimeout( AMOTOS.execute_nav, 20);
        setTimeout( function(){
            AMOTOS.execute_slider_nav();
            //var $car_sync_wrap = $('.pagination-image.amotos-car-slider');
            //AMOTOS.sync_car_carousel($car_sync_wrap);
            AMOTOS.sc_sync_car_carousel();
        }, 10);
    });
})(jQuery);
