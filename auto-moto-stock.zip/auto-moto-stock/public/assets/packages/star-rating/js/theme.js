(function ($) {
    "use strict";
    $.fn.ratingThemes['amotos-svg'] = {
        filledStar: '<i class="fa fa-star"></i>',
        emptyStar: '<i class="fa fa-star-o"></i>',
        clearButton: '<i class="fa fa-minus-circle"></i>'
    };
})(window.jQuery);
